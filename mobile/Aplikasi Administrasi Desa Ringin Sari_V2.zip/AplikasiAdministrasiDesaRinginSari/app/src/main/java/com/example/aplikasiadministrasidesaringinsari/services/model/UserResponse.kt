package com.example.aplikasiadministrasidesaringinsari.services.model

import com.google.gson.annotations.SerializedName

data class UserResponse(
    @SerializedName("id") val id: Int? = null,
    @SerializedName("name") val name: String? = null,
    @SerializedName("username") val username: String? = null,
    @SerializedName("nik") val nik: String? = null,
    @SerializedName("birthInfo") val birthInfo: String? = null,
    @SerializedName("jobTitle") val jobTitle: String? = null,
    @SerializedName("address") val address: String? = null,
    @SerializedName("gender") val gender: Boolean? = null,
    @SerializedName("imageUrl") val imageUrl: String? = null,
)
