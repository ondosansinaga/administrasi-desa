package com.example.aplikasiadministrasidesaringinsari.services.model

import com.google.gson.annotations.SerializedName

data class NewsResponse(
    @SerializedName("id") val id: Int? = null,
    @SerializedName("title") val title: String? = null,
    @SerializedName("content") val content: String? = null,
    @SerializedName("imageUrl") val imageUrl: String? = null,
    @SerializedName("createdAt") val createdAt: String? = null,
    @SerializedName("user") val user:UserResponse? = null,
)