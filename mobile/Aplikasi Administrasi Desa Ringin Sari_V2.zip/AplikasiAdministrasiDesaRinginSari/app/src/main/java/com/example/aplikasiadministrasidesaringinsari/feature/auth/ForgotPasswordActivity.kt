package com.example.aplikasiadministrasidesaringinsari.feature.auth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityForgotPasswordBinding
import com.example.aplikasiadministrasidesaringinsari.helper.closeKeyboard
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ForgotPasswordActivity : AppCompatActivity() {

    private lateinit var binding: ActivityForgotPasswordBinding

    private val services by lazy { ApiService.getInstance() }

    private val loadingDialog by lazy { LoadingDialog(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotPasswordBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.run {
            btnSave.setOnClickListener {
                it.closeKeyboard()

                val username = ivUsername.getText()
                val password = ivPassword.getText()
                val conPassword = ivConPassword.getText()

                if (!inputValidation(username, password, conPassword)) return@setOnClickListener

                forgotPassword(username, password)
            }
        }
    }

    private fun forgotPassword(
        username: String?,
        password: String?,
    ) {
        if (username.isNullOrEmpty()) return
        if (password.isNullOrEmpty()) return

        loadingDialog.show()

        services.forgotPassword(username, password).enqueue(object : Callback<Wrapper<Unit>> {
            override fun onResponse(call: Call<Wrapper<Unit>>, response: Response<Wrapper<Unit>>) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                showInfoDialog(body?.message ?: getString(R.string.network_error)) {
                    if (!responseStatus) return@showInfoDialog
                    finish()
                }
            }

            override fun onFailure(call: Call<Wrapper<Unit>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }

        })
    }

    private fun inputValidation(
        username: String?,
        password: String?,
        conPassword: String?
    ): Boolean {
        if (username.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.username_empty))
            return false
        }

        if (password.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.new_pass_empty))
            return false
        }

        if (conPassword.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.con_pass_empty))
            return false
        }

        if (conPassword != password) {
            showInfoDialog(getString(R.string.con_same_pass))
            return false
        }

        return true
    }

}