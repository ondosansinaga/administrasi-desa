package com.example.aplikasiadministrasidesaringinsari.services.model

import com.google.gson.annotations.SerializedName

data class WrapperPaging<out T>(
    @SerializedName("pageInfo") val pageInfo: PageInfo? = null,
    @SerializedName("status") val status: Boolean? = null,
    @SerializedName("message") val message: String? = null,
    @SerializedName("data") val data: T? = null
)

data class PageInfo(
    @SerializedName("currentPage") val currentPage: Int? = null,
    @SerializedName("from") val from: Int? = null,
    @SerializedName("lastPage") val lastPage: Int? = null,
    @SerializedName("perPage") val perPage: Int? = null,
    @SerializedName("to") val to: Int? = null,
    @SerializedName("total") val total: Int? = null,
)