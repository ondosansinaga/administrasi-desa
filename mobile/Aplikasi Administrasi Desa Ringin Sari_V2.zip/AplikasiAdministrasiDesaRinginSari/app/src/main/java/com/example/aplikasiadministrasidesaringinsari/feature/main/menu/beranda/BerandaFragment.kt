package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.beranda

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.common.views.SpaceDecoration
import com.example.aplikasiadministrasidesaringinsari.databinding.FragmentBerandaBinding
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivity
import com.example.aplikasiadministrasidesaringinsari.feature.main.adapter.PageAdapter
import com.example.aplikasiadministrasidesaringinsari.helper.navTo
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.NewsResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.WrapperPaging
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class BerandaFragment : Fragment() {

    private var _binding: FragmentBerandaBinding? = null
    private val binding get() = _binding

    private val services by lazy { ApiService.getInstance() }

    private val newsAdapter by lazy { NewsAdapter() }

    private val pageAdapter by lazy { PageAdapter() }

    private val loadingDialog by lazy { LoadingDialog(requireContext()) }

    private var selectedPage = 1

    override fun onAttach(context: Context) {
        super.onAttach(context)
        (context as? MainActivity)?.setMenu(MainActivity.MainMenu.BERANDA)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentBerandaBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.run {
            swpNews.setOnRefreshListener {
                getNews(selectedPage)
            }

            rvPage.run {
                layoutManager =
                    LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
                adapter = pageAdapter.apply {
                    setOnItemClickListener {
                        selectedPage = it
                        getNews(selectedPage)
                    }
                }
                setHasFixedSize(true)
            }

            rvNews.run {
                addItemDecoration(SpaceDecoration())
                layoutManager = LinearLayoutManager(requireContext())
                adapter = newsAdapter.apply {
                    setOnItemClickListener {
                        requireActivity().navTo(
                            DetailNewsActivity::class.java,
                        ) {
                            putExtra(DetailNewsActivity.KEY_ID, it)
                        }
                    }
                }
            }
        }

        getNews(selectedPage)
    }

    private fun getNews(page: Int) {
        binding?.tvError?.isVisible = false
        loadingDialog.show()
        newsAdapter.submitData(emptyList())

        services.getNews(page).enqueue(object : Callback<WrapperPaging<List<NewsResponse>>> {
            override fun onResponse(
                call: Call<WrapperPaging<List<NewsResponse>>>,
                response: Response<WrapperPaging<List<NewsResponse>>>
            ) {
                binding?.swpNews?.isRefreshing = false
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                if (!responseStatus) {
                    showInfoDialog(body?.message ?: getString(R.string.network_error))
                    return
                }

                val pageInfo = body?.pageInfo
                val data = body?.data ?: emptyList()

                binding?.tvError?.isVisible = data.isEmpty()
                newsAdapter.submitData(data)

                val last = pageInfo?.lastPage ?: return

                if (last == 1) {
                    selectedPage = 1
                    pageAdapter.submitData(emptyList(), 1)
                    return
                }

                pageAdapter.submitData((1..last).toList(), selectedPage)
            }

            override fun onFailure(call: Call<WrapperPaging<List<NewsResponse>>>, t: Throwable) {
                binding?.swpNews?.isRefreshing = false
                binding?.tvError?.isVisible = true
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }
        })
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

}