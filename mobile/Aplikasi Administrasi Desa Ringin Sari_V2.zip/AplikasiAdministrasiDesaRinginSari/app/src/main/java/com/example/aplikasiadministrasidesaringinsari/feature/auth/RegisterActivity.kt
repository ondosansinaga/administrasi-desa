package com.example.aplikasiadministrasidesaringinsari.feature.auth

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import androidx.appcompat.app.AppCompatActivity
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityRegisterBinding
import com.example.aplikasiadministrasidesaringinsari.helper.WARGA_ROLE_ID
import com.example.aplikasiadministrasidesaringinsari.helper.birthInfoPattern
import com.example.aplikasiadministrasidesaringinsari.helper.closeKeyboard
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.Gender
import com.example.aplikasiadministrasidesaringinsari.services.model.UserResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegisterActivity : AppCompatActivity(), AdapterView.OnItemSelectedListener {

    private lateinit var binding: ActivityRegisterBinding
    private val gender get() = resources.getStringArray(R.array.gender)

    private var selectedGender: Int = -1

    private val services by lazy { ApiService.getInstance() }

    private val loadingDialog by lazy { LoadingDialog(this) }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.run {
            val initGender = mutableListOf<String>(
                getString(R.string.hint_gender),
                *gender,
            )

            spGender.setValueFromArrayList(this@RegisterActivity, initGender)
            spGender.spinner?.onItemSelectedListener = this@RegisterActivity

            btnSignUp.setOnClickListener {
                it.closeKeyboard()

                val nik = ivNik.getText()
                val name = ivName.getText()
                val birth = ivBirth.getText()
                val address = ivAddress.getText()
                val job = ivJobTitle.getText()
                val gender = Gender.getGenderValueInt(selectedGender)
                val username = ivUsername.getText()
                val password = ivPassword.getText()

                if (!inputValidation(
                        nik,
                        name,
                        birth,
                        address,
                        job,
                        gender,
                        username,
                        password
                    )
                ) return@setOnClickListener

                register(
                    nik,
                    name,
                    birth,
                    address,
                    job,
                    gender,
                    username,
                    password
                )
            }
        }
    }

    private fun register(
        nik: String?,
        name: String?,
        birth: String?,
        address: String?,
        job: String?,
        gender: Int?,
        username: String?,
        password: String?,
    ) {
        if (nik.isNullOrEmpty()) return
        if (name.isNullOrEmpty()) return
        if (birth.isNullOrEmpty()) return
        if (address.isNullOrEmpty()) return
        if (job.isNullOrEmpty()) return
        if (gender == null) return
        if (username.isNullOrEmpty()) return
        if (password.isNullOrEmpty()) return

        loadingDialog.show()

        services.register(
            username = username,
            password = password,
            name = name,
            nik = nik,
            address = address,
            birthInfo = birth,
            jobTitle = job,
            gender = gender,
            roleId = WARGA_ROLE_ID,
        ).enqueue(object : Callback<Wrapper<UserResponse>> {
            override fun onResponse(
                call: Call<Wrapper<UserResponse>>,
                response: Response<Wrapper<UserResponse>>
            ) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                showInfoDialog(body?.message ?: getString(R.string.network_error)) {
                    if (!responseStatus) return@showInfoDialog
                    finish()
                }
            }

            override fun onFailure(call: Call<Wrapper<UserResponse>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }

        })
    }

    private fun inputValidation(
        nik: String?,
        name: String?,
        birth: String?,
        address: String?,
        job: String?,
        gender: Int?,
        username: String?,
        password: String?,
    ): Boolean {
        if (nik.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.nik_empty))
            return false
        }

        if (name.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.name_empty))
            return false
        }

        if (birth.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.ttl_empty))
            return false
        }

        if (!birthInfoPattern.matcher(birth).matches()) {
            showInfoDialog(getString(R.string.ttl_invalid))
            return false
        }

        if (address.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.address_empty))
            return false
        }

        if (job.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.job_title_empty))
            return false
        }

        if (gender == -1) {
            showInfoDialog(getString(R.string.gender_empty))
            return false
        }

        if (username.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.username_empty))
            return false
        }

        if (password.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.pass_empty))
            return false
        }

        return true
    }

    override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
        val size = parent.adapter.count

        selectedGender = pos

        if (size == gender.size + 1) {
            if (pos != 0) {
                selectedGender = pos
                binding.spGender.setValueFromArrayList(this@RegisterActivity, listOf(*gender))
            } else {
                selectedGender = -1
            }
        }
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }

}