package com.example.aplikasiadministrasidesaringinsari.common.views

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.widget.LinearLayoutCompat
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ViewInputBinding
import com.example.aplikasiadministrasidesaringinsari.helper.toPx

class InputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : LinearLayoutCompat(context, attrs) {

    private var _binding: ViewInputBinding? = null
    val input get() = _binding?.edtInput

    init {
        _binding = ViewInputBinding.inflate(LayoutInflater.from(context), this)
        setup()
        bindAttr(context, attrs)
    }

    private fun bindAttr(ctx: Context, attrs: AttributeSet?) {
        val typedArr = ctx.obtainStyledAttributes(attrs, R.styleable.InputView)

        val hint = typedArr.getString(R.styleable.InputView_iv_hint)
        val prefixIcon = typedArr.getDrawable(R.styleable.InputView_iv_src_prefix)
        val inputTypeInt = typedArr.getInt(R.styleable.InputView_iv_input_type, 0)
        val inputType = InputType.values().filter {
            it.ordinal == inputTypeInt
        }.firstOrNull() ?: InputType.TEXT

        setHint(hint)
        setInputType(inputType)
        prefixIcon?.let { setPrefixIcon(it) }

        typedArr.recycle()
    }

    private fun setup() {
        orientation = HORIZONTAL
        setPadding(16.toPx(), 0, 16.toPx(), 0)
        setBackgroundResource(R.drawable.bg_input)
        gravity = Gravity.CENTER
        _binding?.edtInput?.setTextColor(Color.BLACK)
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        _binding?.edtInput?.isEnabled = enabled
        _binding?.ivPostfix?.isEnabled = enabled
    }

    fun setInputType(inputType: InputType) {
        when (inputType) {
            InputType.TEXT -> {
                _binding?.edtInput?.inputType = android.text.InputType.TYPE_CLASS_TEXT
            }

            InputType.NUMBER -> {
                _binding?.edtInput?.inputType = android.text.InputType.TYPE_CLASS_NUMBER
            }

            InputType.PASSWORD -> {
                _binding?.edtInput?.inputType =
                    android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD or android.text.InputType.TYPE_CLASS_TEXT
            }

            InputType.VISIBLE_PASSWORD -> {
                _binding?.edtInput?.inputType =
                    android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            }
        }
    }

    fun setTextInput(text: String?) {
        _binding?.edtInput?.setText(text ?: "-")
    }

    fun setHint(text: String?) {
        _binding?.edtInput?.hint = text
    }

    fun setPrefixIcon(drawable: Drawable) {
        _binding?.ivPrefix?.setImageDrawable(drawable)
    }

    fun setPostfixIcon(drawable: Drawable) {
        _binding?.ivPostfix?.run {
            visibility = View.VISIBLE
            setImageDrawable(drawable)
        }
    }

    fun postFixIconOnClickListener(listener: (View?) -> Unit) {
        _binding?.ivPostfix?.run {
            setOnClickListener { listener.invoke(this) }
        }
    }

    fun getText(): String {
        return _binding?.edtInput?.text?.trim().toString()
    }

    fun setText(text: String) {
        _binding?.edtInput?.setText(text)
    }

    override fun detachViewFromParent(child: View?) {
        _binding = null
        super.detachViewFromParent(child)
    }

    enum class InputType {
        TEXT,
        NUMBER,
        PASSWORD,
        VISIBLE_PASSWORD,
    }

}