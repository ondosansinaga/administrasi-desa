package com.example.aplikasiadministrasidesaringinsari.helper

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

typealias VoidCallback = (() -> Unit)

val timeStamp: String = SimpleDateFormat(
    "dd-MMM-yyyy",
    Locale.US
).format(System.currentTimeMillis())

fun formatDateForRequest(dateStr: String?): String? {
    if (dateStr.isNullOrEmpty()) return "-"
    val sdf1 = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
    val date = sdf1.parse(dateStr)
    val sdf2 = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    return date?.let { sdf2.format(it) }
}

fun formatDateTimeStr(dateStr: String?): String? {
    if (dateStr.isNullOrEmpty()) return "-"
    val sdf1 = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
    val date = sdf1.parse(dateStr)
    val sdf2 = SimpleDateFormat("dd-MM-yyyy, HH:mm", Locale.getDefault())
    return date?.let { sdf2.format(it) }
}

fun getCurrentDate(): String {
    val sdf = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
    return sdf.format(Date())
}

fun createCustomTempFile(fileName: String, context: Context): File {
    val storageDir: File? = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)
    return File.createTempFile(fileName, ".jpg", storageDir)
}

fun uriToFile(fileName: String, selectedImg: Uri, context: Context): File {
    val contentResolver: ContentResolver = context.contentResolver
    val myFile = createCustomTempFile(fileName, context)

    val inputStream = contentResolver.openInputStream(selectedImg) as InputStream
    val outputStream: OutputStream = FileOutputStream(myFile)
    val buf = ByteArray(1024)
    var len: Int
    while (inputStream.read(buf).also { len = it } > 0) outputStream.write(buf, 0, len)
    outputStream.close()
    inputStream.close()

    return myFile
}
