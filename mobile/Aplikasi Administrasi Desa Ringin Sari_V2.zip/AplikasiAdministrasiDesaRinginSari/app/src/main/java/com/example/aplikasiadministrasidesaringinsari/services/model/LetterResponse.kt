package com.example.aplikasiadministrasidesaringinsari.services.model

import com.google.gson.annotations.SerializedName

data class LetterResponse(
    @SerializedName("id") val id: Int? = null,
    @SerializedName("title") val title: String? = null,
)