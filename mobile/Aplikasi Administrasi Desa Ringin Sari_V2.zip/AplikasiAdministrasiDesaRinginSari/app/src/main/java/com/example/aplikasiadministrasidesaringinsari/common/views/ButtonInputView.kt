package com.example.aplikasiadministrasidesaringinsari.common.views

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.widget.LinearLayoutCompat
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ViewButtonInputBinding
import com.example.aplikasiadministrasidesaringinsari.helper.toPx

class ButtonInputView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : LinearLayoutCompat(context, attrs) {

    private var _binding: ViewButtonInputBinding? = null

    init {
        _binding = ViewButtonInputBinding.inflate(LayoutInflater.from(context), this)
        setup()
        bindAttr(context, attrs)
    }

    private fun bindAttr(ctx: Context, attrs: AttributeSet?) {
        val typedArr = ctx.obtainStyledAttributes(attrs, R.styleable.ButtonInputView)

        val title = typedArr.getString(R.styleable.ButtonInputView_biv_title)
        val prefixIcon = typedArr.getDrawable(R.styleable.ButtonInputView_biv_src_prefix)

        setTextInput(title)
        prefixIcon?.let { setPrefixIcon(it) }

        typedArr.recycle()
    }

    private fun setup() {
        orientation = HORIZONTAL
        setPadding(16.toPx(), 0, 16.toPx(), 0)
        setBackgroundResource(R.drawable.bg_input)
        gravity = Gravity.CENTER
    }

    fun setTextInput(text: String?) {
        _binding?.tvTitle?.text = text ?: "-"
    }

    fun setPrefixIcon(drawable: Drawable) {
        _binding?.ivPrefix?.setImageDrawable(drawable)
    }

    fun getText(): String {
        return _binding?.tvTitle?.text?.trim().toString()
    }

    override fun detachViewFromParent(child: View?) {
        _binding = null
        super.detachViewFromParent(child)
    }

}