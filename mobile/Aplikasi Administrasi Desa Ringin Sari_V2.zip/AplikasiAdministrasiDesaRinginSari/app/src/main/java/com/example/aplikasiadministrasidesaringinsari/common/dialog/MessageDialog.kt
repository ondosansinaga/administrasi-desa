package com.example.aplikasiadministrasidesaringinsari.common.dialog

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.DialogFragment
import com.example.aplikasiadministrasidesaringinsari.databinding.FragmentMessageDialogBinding
import com.example.aplikasiadministrasidesaringinsari.helper.VoidCallback

class MessageDialog(
    private var title: String? = null,
    private var message: String? = null,
    private var confirmText: String? = null,
    private var cancelText: String? = null,
    private var onConfirm: VoidCallback? = null,
    private var onCancel: VoidCallback? = null,
) : DialogFragment() {

    private var _binding: FragmentMessageDialogBinding? = null
    private val binding get() = _binding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMessageDialogBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupView()
    }

    private fun setupView() {
        binding?.run {
            tvTitle.isVisible = title != null
            tvMessage.isVisible = message != null
            btnCancel.isVisible = cancelText != null
            btnOk.isVisible = confirmText != null

            tvTitle.text = title
            tvMessage.text = message

            btnOk.text = confirmText
            btnCancel.text = cancelText

            btnOk.setOnClickListener {
                dismiss()
                onConfirm?.invoke()
            }
            btnCancel.setOnClickListener {
                dismiss()
                onCancel?.invoke()
            }
        }
    }

    fun setTitle(title: String?) {
        this.title = title
    }

    fun setMessage(message: String?) {
        this.message = message
    }

    fun setConfirmAndClickListener(text: String?, listener: VoidCallback? = null) {
        this.confirmText = text
        this.onConfirm = listener
    }

    fun setCancelAndClickListener(text: String?, listener: VoidCallback? = null) {
        this.cancelText = text
        this.onCancel = listener
    }

    companion object {
        fun build(init: MessageDialog.() -> Unit): MessageDialog {
            return MessageDialog().apply(init)
        }
    }

}