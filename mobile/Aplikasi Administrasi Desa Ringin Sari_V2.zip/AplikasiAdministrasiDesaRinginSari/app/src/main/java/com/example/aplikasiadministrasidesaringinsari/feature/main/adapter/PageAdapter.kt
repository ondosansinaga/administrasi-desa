package com.example.aplikasiadministrasidesaringinsari.feature.main.adapter

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ItemPageBinding

class PageAdapter : RecyclerView.Adapter<PageAdapter.PageViewHolder>() {

    private var selectedIndex = -1
    private val data = mutableListOf<Int>()
    private var listener: ((Int) -> Unit)? = null

    @SuppressLint("NotifyDataSetChanged")
    fun submitData(data: List<Int>, index:Int) {
        this.data.clear()
        this.data.addAll(data)
        selectedIndex = index
        notifyDataSetChanged()
    }

    fun setOnItemClickListener(listener: ((Int) -> Unit)? = null) {
        this.listener = listener
    }

    inner class PageViewHolder(
        private val binding: ItemPageBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        private val context by lazy { binding.root.context }

        fun bind(data: Int) = with(binding) {
            root.text = "$data"
            val redColor = ContextCompat.getColor(context, R.color.red)
            val whiteColor = ContextCompat.getColor(context, R.color.white)

            if (data == selectedIndex) {
                root.backgroundTintList = ColorStateList.valueOf(redColor)
                root.setTextColor(whiteColor)
            } else {
                root.backgroundTintList = ColorStateList.valueOf(whiteColor)
                root.setTextColor(redColor)
            }

            root.setOnClickListener {
                listener?.invoke(data)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PageViewHolder {
        val binding = ItemPageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return PageViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: PageViewHolder, position: Int) {
        holder.bind(data[position])
    }

}