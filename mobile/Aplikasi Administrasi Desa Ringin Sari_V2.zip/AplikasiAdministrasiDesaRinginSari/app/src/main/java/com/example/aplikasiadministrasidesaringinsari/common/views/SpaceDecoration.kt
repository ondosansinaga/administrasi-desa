package com.example.aplikasiadministrasidesaringinsari.common.views

import android.graphics.Rect
import android.view.View
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.ItemDecoration
import com.example.aplikasiadministrasidesaringinsari.helper.toPx

class SpaceDecoration : ItemDecoration() {

    override fun getItemOffsets(
        outRect: Rect,
        view: View,
        parent: RecyclerView,
        state: RecyclerView.State
    ) {
        super.getItemOffsets(outRect, view, parent, state)

        val pos = parent.getChildAdapterPosition(view)
        val size = parent.adapter?.itemCount ?: 0

        outRect.left = 16.toPx()
        outRect.right = 16.toPx()

        if (pos == 0) {
            outRect.top = 16.toPx()
            outRect.bottom = 4.toPx()
            return
        }

        if (pos == size - 1) {
            outRect.top = 4.toPx()
            outRect.bottom = 16.toPx()
            return
        }

        outRect.top = 4.toPx()
        outRect.bottom = 4.toPx()
    }

}