package com.example.aplikasiadministrasidesaringinsari.feature.splash

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.lifecycleScope
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.feature.auth.AuthActivity
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivity
import com.example.aplikasiadministrasidesaringinsari.helper.SPLASH_DELAY
import com.example.aplikasiadministrasidesaringinsari.helper.accountManager
import com.example.aplikasiadministrasidesaringinsari.helper.replaceTo
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private val splashDelay get() = SPLASH_DELAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        lifecycleScope.launch {
            delay(splashDelay)

            if (accountManager().getUserId() != 0) {
                replaceTo(MainActivity::class.java)
            } else {
                replaceTo(AuthActivity::class.java)
            }
        }
    }

}