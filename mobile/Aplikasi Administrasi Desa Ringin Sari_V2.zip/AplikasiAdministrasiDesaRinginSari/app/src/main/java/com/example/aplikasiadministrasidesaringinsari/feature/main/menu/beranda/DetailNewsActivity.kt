package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.beranda

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import coil.load
import coil.transform.RoundedCornersTransformation
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityNewsDetailBinding
import com.example.aplikasiadministrasidesaringinsari.helper.formatDateTimeStr
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.NewsResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailNewsActivity : AppCompatActivity() {

    companion object {
        const val KEY_ID = "KEY_ID"
    }

    private lateinit var binding: ActivityNewsDetailBinding

    private val services by lazy { ApiService.getInstance() }

    private val loadingDialog by lazy { LoadingDialog(this) }

    private val newsId get() = intent.getIntExtra(KEY_ID, -1)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNewsDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        getNewsById(newsId)
    }

    private fun setNews(data: NewsResponse?) = with(binding) {
        val date = formatDateTimeStr(data?.createdAt)

        tvTitleNews.text = data?.title ?: "-"
        tvDesc.text = data?.content ?: "-"
        tvInfo.text = "${data?.user?.name} • $date"

        val imageUrl = "${ApiService.NEWS_URL}${data?.imageUrl}"
        ivNews.load(imageUrl) {
            crossfade(true)
            placeholder(R.drawable.ic_image)
            error(R.drawable.ic_image_broken)
            transformations(RoundedCornersTransformation())
        }
    }

    private fun getNewsById(id: Int) {
        loadingDialog.show()

        services.getNewsById(id).enqueue(object : Callback<Wrapper<NewsResponse>> {
            override fun onResponse(
                call: Call<Wrapper<NewsResponse>>,
                response: Response<Wrapper<NewsResponse>>
            ) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                if (!responseStatus) {
                    showInfoDialog(body?.message ?: getString(R.string.network_error))
                    return
                }

                val data = body?.data

                setNews(data)
            }

            override fun onFailure(call: Call<Wrapper<NewsResponse>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }
        })
    }

}