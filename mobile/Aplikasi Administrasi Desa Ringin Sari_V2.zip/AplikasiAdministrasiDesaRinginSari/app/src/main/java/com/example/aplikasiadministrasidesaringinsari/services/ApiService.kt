package com.example.aplikasiadministrasidesaringinsari.services

import com.example.aplikasiadministrasidesaringinsari.services.model.LetterResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.NewsResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.RequestLetterResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.UserResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import com.example.aplikasiadministrasidesaringinsari.services.model.WrapperPaging
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.GET
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @FormUrlEncoded
    @POST("login-user")
    fun login(
        @Field("username") username: String,
        @Field("password") password: String,
    ): Call<Wrapper<UserResponse>>

    @FormUrlEncoded
    @POST("register-user")
    fun register(
        @Field("username") username: String,
        @Field("password") password: String,
        @Field("name") name: String,
        @Field("nik") nik: String,
        @Field("birthInfo") birthInfo: String,
        @Field("address") address: String,
        @Field("jobTitle") jobTitle: String,
        @Field("gender") gender: Int,
        @Field("roleId") roleId: Int,
    ): Call<Wrapper<UserResponse>>

    @FormUrlEncoded
    @POST("forgot-pass-user")
    fun forgotPassword(
        @Field("username") username: String,
        @Field("newPassword") newPassword: String,
    ): Call<Wrapper<Unit>>

    @GET("users/{userId}")
    fun getUserById(
        @Path("userId") userId: Int,
    ): Call<Wrapper<UserResponse>>

    @GET("letters")
    fun getLetters(): Call<Wrapper<List<LetterResponse>>>

    @GET("letters/{id}")
    fun getLetterById(
        @Path("id") id: Int
    ): Call<Wrapper<LetterResponse>>

    @POST("edit-user/{userId}")
    @Multipart
    fun updateUser(
        @Path("userId") userId: Int,
        @Part image: MultipartBody.Part? = null,
        @Part("nik") nik: RequestBody?,
        @Part("name") name: RequestBody?,
        @Part("birthInfo") birthInfo: RequestBody?,
        @Part("jobTitle") jobTitle: RequestBody?,
        @Part("address") address: RequestBody?,
        @Part("gender") gender: RequestBody?,
    ): Call<Wrapper<Unit>>

    @GET("news")
    fun getNews(
        @Query("page") page: Int = 1,
    ): Call<WrapperPaging<List<NewsResponse>>>

    @GET("news/{id}")
    fun getNewsById(
        @Path("id") id: Int
    ): Call<Wrapper<NewsResponse>>

    @FormUrlEncoded
    @POST("create-req-letters")
    fun createRequestLetter(
        @Field("userId") userId: Int,
        @Field("letterId") letterId: Int,
        @Field("dateRequest") dateRequest: String,
    ): Call<Wrapper<Unit>>

    @GET("req-letters/{userId}")
    fun getRequestLetters(
        @Path("userId") userId: Int,
        @Query("page") page:Int,
    ): Call<WrapperPaging<List<RequestLetterResponse>>>

    companion object {
        //const val BASE_URL = "http://192.168.200.241:8000"
        const val BASE_URL = "http://192.168.1.9/administrasi-desa/public"
        const val PROFILE_URL = "$BASE_URL/storage/images/profile/"
        const val NEWS_URL = "$BASE_URL/storage/images/news/"
        const val DOC_URL = "$BASE_URL/storage/documents/"

        private val BASE_URL_API = "$BASE_URL/api/"

        fun getInstance(): ApiService {
            return Retrofit.Builder()
                .baseUrl(BASE_URL_API)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
    }

}