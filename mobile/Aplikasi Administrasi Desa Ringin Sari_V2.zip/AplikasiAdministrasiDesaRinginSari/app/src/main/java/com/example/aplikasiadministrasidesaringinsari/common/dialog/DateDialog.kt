package com.example.aplikasiadministrasidesaringinsari.common.dialog

import android.app.DatePickerDialog
import android.content.Context
import java.util.Calendar
import java.util.Date

class DateDialog(private val context: Context) {

    private val c = Calendar.getInstance()
    var year = c.get(Calendar.YEAR)
        private set
    var month = c.get(Calendar.MONTH)
        private set
    var day = c.get(Calendar.DAY_OF_MONTH)
        private set

    fun showDateDialog(limit:Boolean = true,result: (String?) -> Unit) {
        val dialog = DatePickerDialog(context, { _, y, m, d ->
            year = y
            month = m
            day = d

            result("$day-${month + 1}-${year}")
        }, year, month, day)

        if (limit) {
            dialog.datePicker.minDate = Date().time
        }
        dialog.show()
    }

}