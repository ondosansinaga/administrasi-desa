package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.riwayat

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityDetailRiwayatPengajuanBinding
import com.example.aplikasiadministrasidesaringinsari.services.ApiService.Companion.DOC_URL


class DetailRiwayatPengajuanActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailRiwayatPengajuanBinding

    private val docIntent get() = intent.getStringExtra(EXTRA_DOC)
    private val docUrl get() = "${DOC_URL}${docIntent}"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailRiwayatPengajuanBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.run {
            tbMain.actionOnClickListener {
                openUrl(docUrl)
            }
        }

        loadWebView()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun loadWebView() = with(binding) {
        val url = "https://docs.google.com/gview?embedded=true&url=$docUrl"
        webView.settings.javaScriptEnabled = true
        webView.settings.setSupportZoom(true);
        webView.clearHistory()
        webView.loadUrl(url)
    }

    private fun openUrl(url: String) {
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        startActivity(i)
    }

    companion object {
        const val EXTRA_DOC = "EXTRA_DOC"
    }

}