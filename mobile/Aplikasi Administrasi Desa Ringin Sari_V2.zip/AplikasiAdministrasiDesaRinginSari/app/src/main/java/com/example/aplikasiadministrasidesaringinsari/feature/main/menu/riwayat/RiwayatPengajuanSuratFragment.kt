package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.riwayat

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.common.views.SpaceDecoration
import com.example.aplikasiadministrasidesaringinsari.databinding.FragmentRiwayatPengajuanSuratBinding
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivity
import com.example.aplikasiadministrasidesaringinsari.feature.main.adapter.PageAdapter
import com.example.aplikasiadministrasidesaringinsari.feature.main.menu.beranda.NewsAdapter
import com.example.aplikasiadministrasidesaringinsari.helper.accountManager
import com.example.aplikasiadministrasidesaringinsari.helper.navTo
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.ApiService.Companion.DOC_URL
import com.example.aplikasiadministrasidesaringinsari.services.model.NewsResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.RequestLetterResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.WrapperPaging
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RiwayatPengajuanSuratFragment : Fragment() {

    private var _binding: FragmentRiwayatPengajuanSuratBinding? = null
    private val binding get() = _binding

    private val services by lazy { ApiService.getInstance() }

    private val letterAdapter by lazy { LetterAdapter() }

    private val pageAdapter by lazy { PageAdapter() }

    private val loadingDialog by lazy { LoadingDialog(requireContext()) }

    private var selectedPage = 1



    override fun onAttach(context: Context) {
        super.onAttach(context)
        (context as? MainActivity)?.setMenu(MainActivity.MainMenu.RIWAYAT)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentRiwayatPengajuanSuratBinding.inflate(inflater, container, false)
        return binding?.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)



        binding?.run {
            swpRiwayat.setOnRefreshListener {
                getLetters(selectedPage)
            }

            rvPage.run {
                layoutManager =
                    LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
                adapter = pageAdapter.apply {
                    setOnItemClickListener {
                        selectedPage = it
                        getLetters(selectedPage)
                    }
                }
                setHasFixedSize(true)
            }

            rvRiwayat.run {
                addItemDecoration(SpaceDecoration())
                layoutManager = LinearLayoutManager(requireContext())
                adapter = letterAdapter.apply {
                    setOnItemClickListener { docUrl ->
                        val url = "${DOC_URL}${docUrl}"
                        openUrl(url)
//                        requireActivity().navTo(DetailRiwayatPengajuanActivity::class.java) {
//                            putExtra(DetailRiwayatPengajuanActivity.EXTRA_DOC, docUrl)
//                        }
                    }
                }
            }
        }

        getLetters(selectedPage)
    }

    private fun openUrl(url: String) {
        val i = Intent(Intent.ACTION_VIEW)
        i.data = Uri.parse(url)
        startActivity(i)
    }

    private fun getLetters(page: Int) {
        binding?.tvError?.isVisible = false
        val userId = requireActivity().accountManager().getUserId() ?: return
        loadingDialog.show()
        letterAdapter.submitData(emptyList())

        services.getRequestLetters(userId, page)
            .enqueue(object : Callback<WrapperPaging<List<RequestLetterResponse>>> {
                override fun onResponse(
                    call: Call<WrapperPaging<List<RequestLetterResponse>>>,
                    response: Response<WrapperPaging<List<RequestLetterResponse>>>
                ) {
                    binding?.swpRiwayat?.isRefreshing = false
                    loadingDialog.hide()

                    val body = response.body()
                    val responseStatus = body?.status ?: false

                    if (!responseStatus) {
                        showInfoDialog(body?.message ?: getString(R.string.network_error))
                        return
                    }

                    val pageInfo = body?.pageInfo
                    val data = body?.data ?: emptyList()

                    binding?.tvError?.isVisible = data.isEmpty()
                    letterAdapter.submitData(data)

                    val last = pageInfo?.lastPage ?: return

                    if (last == 1) {
                        selectedPage = 1
                        pageAdapter.submitData(emptyList(), 1)
                        return
                    }

                    pageAdapter.submitData((1..last).toList(), selectedPage)
                }

                override fun onFailure(
                    call: Call<WrapperPaging<List<RequestLetterResponse>>>,
                    t: Throwable
                ) {
                    binding?.swpRiwayat?.isRefreshing = false
                    binding?.tvError?.isVisible = true
                    loadingDialog.hide()
                    showInfoDialog(getString(R.string.network_error))
                }

            })
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

}