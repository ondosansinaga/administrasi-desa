package com.example.aplikasiadministrasidesaringinsari.common.dialog

import android.content.Context
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import com.example.aplikasiadministrasidesaringinsari.R

class LoadingDialog(context: Context) {

    private var dialog: AlertDialog? = null

    init {
        dialog = AlertDialog.Builder(context, R.style.CustomDialog)
            .setView(ProgressBar(context))
            .setCancelable(false)
            .create()
    }

    fun show() {
        dialog?.show()
    }

    fun hide() {
        dialog?.dismiss()
    }

}