package com.example.aplikasiadministrasidesaringinsari.feature.auth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityLoginBinding
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivity
import com.example.aplikasiadministrasidesaringinsari.helper.accountManager
import com.example.aplikasiadministrasidesaringinsari.helper.closeKeyboard
import com.example.aplikasiadministrasidesaringinsari.helper.navTo
import com.example.aplikasiadministrasidesaringinsari.helper.replaceTo
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.UserResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    private val services by lazy { ApiService.getInstance() }

    private val loadingDialog by lazy { LoadingDialog(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.run {
            tvForgotPass.setOnClickListener {
                it.closeKeyboard()

                navTo(ForgotPasswordActivity::class.java)
            }

            btnLogin.setOnClickListener {
                it.closeKeyboard()

                val username = binding.ivUsername.getText()
                val password = binding.ivPassword.getText()

                if (!inputValidation(username, password)) return@setOnClickListener
                login(username, password)
            }
        }
    }

    private fun login(username: String?, password: String?) {
        if (username.isNullOrEmpty() || password.isNullOrEmpty()) return

        loadingDialog.show()

        services.login(
            username = username,
            password = password
        ).enqueue(object : Callback<Wrapper<UserResponse>> {
            override fun onResponse(
                call: Call<Wrapper<UserResponse>>,
                response: Response<Wrapper<UserResponse>>
            ) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                if (!responseStatus) {
                    showInfoDialog(body?.message ?: getString(R.string.network_error))
                    return
                }

                val userId = body?.data?.id
                accountManager().setUserId(userId)
                replaceTo(MainActivity::class.java)
            }

            override fun onFailure(call: Call<Wrapper<UserResponse>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }
        })
    }

    private fun inputValidation(
        username: String?,
        password: String?
    ): Boolean {
        if (username.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.username_empty))
            return false
        }

        if (password.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.pass_empty))
            return false
        }

        return true
    }

}