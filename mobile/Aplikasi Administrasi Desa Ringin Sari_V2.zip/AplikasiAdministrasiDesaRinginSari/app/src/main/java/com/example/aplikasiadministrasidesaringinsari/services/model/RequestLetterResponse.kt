package com.example.aplikasiadministrasidesaringinsari.services.model

import com.google.gson.annotations.SerializedName

data class RequestLetterResponse(
    @SerializedName("id") val id: Int? = null,
    @SerializedName("docUrl") val docUrl: String? = null,
    @SerializedName("status") val status: Int? = null,
    @SerializedName("dateRequest") val dateRequest: String? = null,
    @SerializedName("dateStatus") val dateStatus: String? = null,
    @SerializedName("user") val user: UserResponse? = null,
    @SerializedName("letter") val letter: LetterResponse? = null,
)