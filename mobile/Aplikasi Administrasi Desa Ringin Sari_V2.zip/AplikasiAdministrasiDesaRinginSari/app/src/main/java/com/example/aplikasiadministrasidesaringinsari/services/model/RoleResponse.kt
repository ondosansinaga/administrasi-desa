package com.example.aplikasiadministrasidesaringinsari.services.model

import com.google.gson.annotations.SerializedName

data class RoleResponse(
    @SerializedName("id") val id: Int? = null,
    @SerializedName("name") val name: String? = null,
)