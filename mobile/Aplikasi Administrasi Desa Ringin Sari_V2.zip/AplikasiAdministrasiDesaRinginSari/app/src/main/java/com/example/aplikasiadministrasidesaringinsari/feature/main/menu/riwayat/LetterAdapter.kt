package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.riwayat

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ItemLetterBinding
import com.example.aplikasiadministrasidesaringinsari.services.model.RequestLetterResponse
import com.google.android.material.color.MaterialColors.getColor

class LetterAdapter : RecyclerView.Adapter<LetterAdapter.LetterViewHolder>() {

    private val data = mutableListOf<RequestLetterResponse>()
    private var listener: ((String) -> Unit)? = null


    @SuppressLint("NotifyDataSetChanged")
    fun submitData(data: List<RequestLetterResponse>) {
        this.data.clear()
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    fun setOnItemClickListener(listener: ((String) -> Unit)? = null) {
        this.listener = listener
    }

    inner class LetterViewHolder(
        private val binding: ItemLetterBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(data: RequestLetterResponse) = with(binding) {
            ivFile.visibility = View.GONE
            tvJenisSurat.text = data.letter?.title
            tvTabelJenisFile.visibility = View.GONE
            tvName.text = data.user?.name
            tvNik.text = data.user?.nik
            /*tvStatus.text = PengajuanSuratStatus.fromResponse(data.status ?: -1).toString()*/
            val status = PengajuanSuratStatus.fromResponse(data.status ?: -1)
            tvStatus.text = status.toString()
            when (status) {
                PengajuanSuratStatus.ACCEPTED -> {
                    tvStatus.background = ContextCompat.getDrawable(itemView.context, R.drawable.bg_status_accept)
                    tvStatus.setTextColor(ContextCompat.getColor(itemView.context, R.color.black))
                    tvTabelJenisFile.visibility = View.VISIBLE
                    ivFile.visibility = View.VISIBLE

                }

                PengajuanSuratStatus.PENDING -> {
                    tvStatus.background = ContextCompat.getDrawable(itemView.context, R.drawable.bg_status_pending)
                    tvStatus.setTextColor(ContextCompat.getColor(itemView.context, R.color.black))
                    tvTabelJenisFile.visibility = View.GONE
                    ivFile.visibility = View.GONE

                }
                PengajuanSuratStatus.REJECT -> {
                    tvStatus.background = ContextCompat.getDrawable(itemView.context, R.drawable.bg_status_reject)
                    tvStatus.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                    tvTabelJenisFile.visibility = View.GONE
                    ivFile.visibility = View.GONE

                }
            }




            root.setOnClickListener {
                if (data.docUrl == null) return@setOnClickListener
                listener?.invoke(data.docUrl)
            }

        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LetterViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = ItemLetterBinding.inflate(inflater, parent, false)
        return LetterViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: LetterViewHolder, position: Int) {
        holder.bind(data[position])
    }

}