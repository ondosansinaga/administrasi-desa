package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.profile

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.MutableLiveData
import coil.load
import coil.transform.CircleCropTransformation
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.databinding.FragmentProfileBinding
import com.example.aplikasiadministrasidesaringinsari.feature.auth.AuthActivity
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivity
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivityListener
import com.example.aplikasiadministrasidesaringinsari.helper.accountManager
import com.example.aplikasiadministrasidesaringinsari.helper.birthInfoPattern
import com.example.aplikasiadministrasidesaringinsari.helper.closeKeyboard
import com.example.aplikasiadministrasidesaringinsari.helper.getValue
import com.example.aplikasiadministrasidesaringinsari.helper.replaceTo
import com.example.aplikasiadministrasidesaringinsari.helper.showConfirmDialog
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.helper.timeStamp
import com.example.aplikasiadministrasidesaringinsari.helper.uriToFile
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.ApiService.Companion.BASE_URL
import com.example.aplikasiadministrasidesaringinsari.services.ApiService.Companion.PROFILE_URL
import com.example.aplikasiadministrasidesaringinsari.services.model.Gender
import com.example.aplikasiadministrasidesaringinsari.services.model.UserResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileFragment : Fragment(), AdapterView.OnItemSelectedListener {

    private val GALLERY_REQUEST_CODE = 100

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding

    private var activityListener: MainActivityListener? = null

    private val editLive = MutableLiveData(false)

    private var selectedGender: Int = -1

    private val services by lazy { ApiService.getInstance() }

    private val loadingDialog by lazy { LoadingDialog(requireContext()) }

    private var userResponse: UserResponse? = null

    private var selectedImageUri: Uri? = null

    private fun photoUrl(imageUrl: String?) = "$PROFILE_URL${imageUrl}"

    override fun onAttach(context: Context) {
        super.onAttach(context)
        activityListener = (context as? MainActivity)
        activityListener?.setMenu(MainActivity.MainMenu.PROFIL)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        editLive.observe(viewLifecycleOwner) { isEdit ->
            if (!isEdit && userResponse != null) {
                setUserData(userResponse)
            }

            binding?.llEditFalse?.isVisible = !isEdit
            binding?.llEditTrue?.isVisible = isEdit

            binding?.tvPhoto?.isVisible = isEdit

            binding?.tvPhoto?.text = getString(
                if (userResponse?.imageUrl != null) {
                    R.string.edit_photo
                } else {
                    R.string.add_photo
                }
            )

            if (isEdit) {
                activityListener?.setMenu(MainActivity.MainMenu.EDIT_PROFIL)
            } else {
                activityListener?.setMenu(MainActivity.MainMenu.PROFIL)
            }

            binding?.llPhoto?.isEnabled = isEdit
            binding?.ivNik?.isEnabled = isEdit
            binding?.ivName?.isEnabled = isEdit
            binding?.ivAddress?.isEnabled = isEdit
            binding?.ivBirth?.isEnabled = isEdit
            binding?.ivJobTitle?.isEnabled = isEdit
            binding?.spGender?.isEnabled = isEdit
        }

        binding?.run {
            spGender.setValueFromArrayList(
                requireContext(), listOf(*resources.getStringArray(R.array.gender))
            )
            spGender.spinner?.onItemSelectedListener = this@ProfileFragment

            tvLogout.setOnClickListener { doLogout() }

            tvEdit.setOnClickListener {
                editLive.value = true
            }

            tvCancel.setOnClickListener {
                editLive.value = false
            }

            llPhoto.setOnClickListener {
                openGallery()
            }

            tvSave.setOnClickListener {
                val imageUri = selectedImageUri
                val nik = ivNik.getText().getValue()
                val name = ivName.getText().getValue()
                val address = ivAddress.getText().getValue()
                val jobTitle = ivJobTitle.getText().getValue()
                val gender = Gender.getGenderValueInt(selectedGender)
                val ttl = ivBirth.getText().getValue()

                if (!inputValidation(nik, name, ttl)) return@setOnClickListener

                updateProfile(imageUri, nik, name, address, jobTitle, gender, ttl)
            }
        }

        getUserInfo()
    }

    private fun updateProfile(
        imageUri: Uri?,
        nik: String?,
        name: String?,
        address: String?,
        jobTitle: String?,
        gender: Int,
        ttl: String?,
    ) {
        if (name.isNullOrEmpty() || nik.isNullOrEmpty()) return
        val userId = userResponse?.id ?: return

        val nameBody = name.toRequestBody("text/plain".toMediaType())
        val nikBody = nik.toRequestBody("text/plain".toMediaType())
        val genderBody = "$gender".toRequestBody("text/plain".toMediaType())
        val addressBody = address?.toRequestBody("text/plain".toMediaType())
        val jobTitleBody = jobTitle?.toRequestBody("text/plain".toMediaType())
        val ttlBody = ttl?.toRequestBody("text/plain".toMediaType())

        val file = imageUri?.let { uriToFile(timeStamp, it, requireContext()) }

        val imageReq = if (file != null) {
            val imageBody = file.asRequestBody("image/*".toMediaTypeOrNull())
            MultipartBody.Part.createFormData("image", file.name, imageBody)
        } else {
            null
        }

        loadingDialog.show()

        services.updateUser(
            userId,
            imageReq,
            nikBody,
            nameBody,
            ttlBody,
            jobTitleBody,
            addressBody,
            genderBody,
        ).enqueue(object : Callback<Wrapper<Unit>> {
            override fun onResponse(call: Call<Wrapper<Unit>>, response: Response<Wrapper<Unit>>) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                showInfoDialog(body?.message ?: getString(R.string.network_error), true) {
                    if (!responseStatus) return@showInfoDialog
                    getUserInfo()
                    editLive.value = false
                    binding?.root?.closeKeyboard()
                }

            }

            override fun onFailure(call: Call<Wrapper<Unit>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }

        })
    }

    private fun inputValidation(
        nik: String?,
        name: String?,
        ttl: String?,
    ): Boolean {
        if (nik.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.nik_empty))
            return false
        }

        if (name.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.name_empty))
            return false
        }

        if (ttl != null && !birthInfoPattern.matcher(ttl).matches()) {
            showInfoDialog(getString(R.string.ttl_invalid))
            return false
        }

        return true
    }

    private fun openGallery() {
        val galleryIntent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(galleryIntent, GALLERY_REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK) return
        if (requestCode != GALLERY_REQUEST_CODE) return

        selectedImageUri = data?.data
        binding?.tvPhoto?.text = getString(R.string.edit_photo)
        binding?.ivProfile?.load(selectedImageUri) {
            crossfade(true)
            placeholder(R.drawable.ic_profile)
            error(R.drawable.ic_profile)
            transformations(CircleCropTransformation())
        }
    }

    private fun doLogout() {
        showConfirmDialog(
            getString(R.string.information),
            getString(R.string.logout_message),
            positiveText = getString(R.string.ya),
            negativeText = getString(R.string.tidak),
        ) {
            requireActivity().accountManager().removeUserId()
            requireActivity().replaceTo(AuthActivity::class.java)
        }
    }

    private fun setUserData(data: UserResponse?) {
        binding?.run {
            val gender = data?.gender ?: false
            val genderInt = if (gender) 0 else 1

            ivNik.setTextInput(data?.nik)
            ivAddress.setTextInput(data?.address)
            ivName.setTextInput(data?.name)
            ivBirth.setTextInput(data?.birthInfo)
            ivJobTitle.setTextInput(data?.jobTitle)

            spGender.activeSpinner(genderInt)
            selectedGender = genderInt

            ivProfile.load(photoUrl(data?.imageUrl)) {
                crossfade(true)
                placeholder(R.drawable.ic_profile)
                error(R.drawable.ic_profile)
                transformations(CircleCropTransformation())
            }
        }

    }

    private fun getUserInfo() {
        val userId = requireActivity().accountManager().getUserId() ?: return

        loadingDialog.show()

        services.getUserById(userId).enqueue(object : Callback<Wrapper<UserResponse>> {
            override fun onResponse(
                call: Call<Wrapper<UserResponse>>,
                response: Response<Wrapper<UserResponse>>
            ) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                if (!responseStatus) {
                    showInfoDialog(body?.message ?: getString(R.string.network_error))
                    return
                }

                val data = body?.data
                userResponse = data
                setUserData(data)
            }

            override fun onFailure(call: Call<Wrapper<UserResponse>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }
        })
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
        selectedGender = pos
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }

}