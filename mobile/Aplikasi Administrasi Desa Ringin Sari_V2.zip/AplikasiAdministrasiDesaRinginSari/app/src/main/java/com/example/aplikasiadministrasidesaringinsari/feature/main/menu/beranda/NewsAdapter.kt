package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.beranda

import android.annotation.SuppressLint
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import coil.load
import coil.transform.RoundedCornersTransformation
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ItemNewsBinding
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.NewsResponse

class NewsAdapter : RecyclerView.Adapter<NewsAdapter.NewsViewHolder>() {

    private val data = mutableListOf<NewsResponse>()
    private var listener: ((Int) -> Unit)? = null

    @SuppressLint("NotifyDataSetChanged")
    fun submitData(data: List<NewsResponse>) {
        this.data.clear()
        this.data.addAll(data)
        notifyDataSetChanged()
    }

    fun setOnItemClickListener(listener: ((Int) -> Unit)? = null) {
        this.listener = listener
    }

    inner class NewsViewHolder(
        private val binding: ItemNewsBinding
    ) : RecyclerView.ViewHolder(binding.root) {

        fun bind(data: NewsResponse) = with(binding) {
            Log.d("NEWS", "${ApiService.NEWS_URL}${data.imageUrl}")
            
            tvTitle.text = data.title
            tvDesc.text = data.content
            ivPic.load("${ApiService.NEWS_URL}${data.imageUrl}") {
                crossfade(true)
                placeholder(R.drawable.ic_image)
                error(R.drawable.ic_image_broken)
                transformations(RoundedCornersTransformation())
            }

            root.setOnClickListener {
                data.id?.let { id -> listener?.invoke(id) }
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NewsViewHolder {
        val binding = ItemNewsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return NewsViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    override fun onBindViewHolder(holder: NewsViewHolder, position: Int) {
        holder.bind(data[position])
    }

}