package com.example.aplikasiadministrasidesaringinsari.common.views

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import androidx.annotation.StringRes
import androidx.appcompat.widget.LinearLayoutCompat
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.core.view.setPadding
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ViewToolbarBinding
import com.example.aplikasiadministrasidesaringinsari.helper.toPx

class ToolbarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : LinearLayoutCompat(context, attrs) {

    private var _binding: ViewToolbarBinding? = null

    init {
        _binding = ViewToolbarBinding.inflate(LayoutInflater.from(context), this)
        setup()
        bindAttr(context, attrs)
    }

    private fun bindAttr(ctx: Context, attrs: AttributeSet?) {
        val typedArr = ctx.obtainStyledAttributes(attrs, R.styleable.ToolbarView)
        val title = typedArr.getString(R.styleable.ToolbarView_tv_title)
        val icActDrawable = typedArr.getDrawable(R.styleable.ToolbarView_tv_src_action)

        setTitle(title)
        icActDrawable?.let { setActionDrawable(it) }

        typedArr.recycle()
    }

    private fun setup() {
        orientation = HORIZONTAL
        setPadding(16.toPx())
        setBackgroundColor(ContextCompat.getColor(context, R.color.red))
        gravity = Gravity.BOTTOM
    }

    fun setTitle(@StringRes titleRes: Int) {
        _binding?.tvTitle?.text = context.getString(titleRes)
    }

    fun setTitle(title: String?) {
        _binding?.tvTitle?.text = title
    }

    fun setActionDrawable(drawable: Drawable?) {
        _binding?.ivAction?.visibility = if (drawable != null) View.VISIBLE else View.INVISIBLE
        _binding?.ivAction?.setImageDrawable(drawable)
    }

    fun setActionImageResource(imageRes: Int?) {
        _binding?.ivAction?.visibility = if (imageRes != null) View.VISIBLE else View.INVISIBLE
        if (imageRes == null) return
        _binding?.ivAction?.setImageResource(imageRes)
    }

    fun actionOnClickListener(listener: (View?) -> Unit) {
        _binding?.ivAction?.run {
            setOnClickListener { listener.invoke(this) }
        }
    }

    override fun detachViewFromParent(child: View?) {
        _binding = null
        super.detachViewFromParent(child)
    }

}