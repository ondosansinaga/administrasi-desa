package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.riwayat

enum class PengajuanSuratStatus(val status: Int) {
    PENDING(0),
    ACCEPTED(1),
    REJECT(2);

    companion object {
        fun fromResponse(data: Int): PengajuanSuratStatus {
            return when (data) {
                0 -> PENDING
                1 -> ACCEPTED
                2 -> REJECT
                else -> PENDING
            }
        }
    }

}