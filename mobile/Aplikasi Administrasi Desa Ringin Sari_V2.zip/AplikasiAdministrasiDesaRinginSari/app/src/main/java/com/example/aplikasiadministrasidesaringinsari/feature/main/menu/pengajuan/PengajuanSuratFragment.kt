package com.example.aplikasiadministrasidesaringinsari.feature.main.menu.pengajuan

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import androidx.fragment.app.Fragment
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.common.dialog.DateDialog
import com.example.aplikasiadministrasidesaringinsari.common.dialog.LoadingDialog
import com.example.aplikasiadministrasidesaringinsari.databinding.FragmentPengajuanSuratBinding
import com.example.aplikasiadministrasidesaringinsari.feature.main.MainActivity
import com.example.aplikasiadministrasidesaringinsari.helper.accountManager
import com.example.aplikasiadministrasidesaringinsari.helper.formatDateForRequest
import com.example.aplikasiadministrasidesaringinsari.helper.getCurrentDate
import com.example.aplikasiadministrasidesaringinsari.helper.showInfoDialog
import com.example.aplikasiadministrasidesaringinsari.services.ApiService
import com.example.aplikasiadministrasidesaringinsari.services.model.LetterResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.UserResponse
import com.example.aplikasiadministrasidesaringinsari.services.model.Wrapper
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PengajuanSuratFragment : Fragment(), AdapterView.OnItemSelectedListener {

    private var _binding: FragmentPengajuanSuratBinding? = null
    private val binding get() = _binding

    private val services by lazy { ApiService.getInstance() }

    private val loadingDialog by lazy { LoadingDialog(requireContext()) }

    private val dateDialog by lazy { DateDialog(requireContext()) }

    private val dataTipeSurat = mutableListOf<LetterResponse>()

    private var selectedSurat: Int = -1

    override fun onAttach(context: Context) {
        super.onAttach(context)
        (context as? MainActivity)?.setMenu(MainActivity.MainMenu.PENGAJUAN)
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPengajuanSuratBinding.inflate(inflater, container, false)
        return binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding?.run {
            ivNik.isEnabled = false
            ivName.isEnabled = false
            ivAddress.isEnabled = false
            ivBirth.isEnabled = false
            ivJobTitle.isEnabled = false
            ivGender.isEnabled = false

            biDatePengajuan.setTextInput(getCurrentDate())
            biDatePengajuan.setOnClickListener {
                dateDialog.showDateDialog(false) { date ->
                    biDatePengajuan.setTextInput(date)
                }
            }

            btnSave.setOnClickListener {
                val userId = requireActivity().accountManager()
                    .getUserId() ?: return@setOnClickListener
                val suratPos = selectedSurat
                val dateRequest = formatDateForRequest(biDatePengajuan.getText())

                if (!inputValidation(suratPos, dateRequest)) return@setOnClickListener

                val suratId = dataTipeSurat[suratPos].id
                saveReqLetter(userId, suratId, dateRequest)
            }
        }

        getData()
    }

    private fun getData() {
        getUserInfo()
        getLetters()
    }

    private fun inputValidation(
        suratPos: Int?,
        dateRequest: String?,
    ): Boolean {
        if (suratPos == null || suratPos < 0) {
            showInfoDialog(getString(R.string.letter_empty))
            return false
        }

        if (dateRequest.isNullOrEmpty()) {
            showInfoDialog(getString(R.string.date_empty))
            return false
        }

        return true
    }

    private fun saveReqLetter(
        userId: Int?,
        suratId: Int?,
        dateRequest: String?,
    ) {
        if (userId == null || suratId == null || dateRequest.isNullOrEmpty()) return

        loadingDialog.show()

        services.createRequestLetter(userId, suratId, dateRequest).enqueue(
            object : Callback<Wrapper<Unit>> {
                override fun onResponse(
                    call: Call<Wrapper<Unit>>,
                    response: Response<Wrapper<Unit>>
                ) {
                    loadingDialog.hide()

                    val body = response.body()
                    val responseStatus = body?.status ?: false

                    showInfoDialog(body?.message ?: getString(R.string.network_error), false) {
                        if (!responseStatus) return@showInfoDialog
                        getData()
                    }
                }

                override fun onFailure(call: Call<Wrapper<Unit>>, t: Throwable) {
                    loadingDialog.hide()
                    showInfoDialog(getString(R.string.network_error))
                }

            }
        )
    }

    private fun setUserData(data: UserResponse?) {
        binding?.run {
            val gender = data?.gender ?: false
            val genderRes = resources.getStringArray(R.array.gender)

            ivNik.setTextInput(data?.nik)
            ivAddress.setTextInput(data?.address)
            ivName.setTextInput(data?.name)
            ivBirth.setTextInput(data?.birthInfo)
            ivJobTitle.setTextInput(data?.jobTitle)

            ivGender.setTextInput(
                if (gender) {
                    genderRes[0]
                } else {
                    genderRes[1]
                }
            )
        }

    }

    private fun setLetters(data: List<LetterResponse>) {
        binding?.spSurat?.run {
            setValueFromArrayList(requireContext(), data.map {
                it.title
            })
            spinner?.onItemSelectedListener = this@PengajuanSuratFragment
        }
    }

    private fun getUserInfo() {
        val userId = requireActivity().accountManager().getUserId() ?: return

        loadingDialog.show()

        services.getUserById(userId).enqueue(object : Callback<Wrapper<UserResponse>> {
            override fun onResponse(
                call: Call<Wrapper<UserResponse>>,
                response: Response<Wrapper<UserResponse>>
            ) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                if (!responseStatus) {
                    showInfoDialog(body?.message ?: getString(R.string.network_error))
                    return
                }

                setUserData(body?.data)
            }

            override fun onFailure(call: Call<Wrapper<UserResponse>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }
        })
    }

    private fun getLetters() {
        dataTipeSurat.clear()

        loadingDialog.show()

        services.getLetters().enqueue(object : Callback<Wrapper<List<LetterResponse>>> {
            override fun onResponse(
                call: Call<Wrapper<List<LetterResponse>>>,
                response: Response<Wrapper<List<LetterResponse>>>
            ) {
                loadingDialog.hide()

                val body = response.body()
                val responseStatus = body?.status ?: false

                if (!responseStatus) {
                    showInfoDialog(body?.message ?: getString(R.string.network_error))
                    return
                }

                val data = body?.data ?: emptyList()

                if (data.isNotEmpty()) {
                    selectedSurat = 0
                }
                dataTipeSurat.addAll(data)

                setLetters(data)
            }

            override fun onFailure(call: Call<Wrapper<List<LetterResponse>>>, t: Throwable) {
                loadingDialog.hide()
                showInfoDialog(getString(R.string.network_error))
            }

        })
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    override fun onItemSelected(parent: AdapterView<*>, view: View?, pos: Int, id: Long) {
        selectedSurat = pos
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {

    }

}