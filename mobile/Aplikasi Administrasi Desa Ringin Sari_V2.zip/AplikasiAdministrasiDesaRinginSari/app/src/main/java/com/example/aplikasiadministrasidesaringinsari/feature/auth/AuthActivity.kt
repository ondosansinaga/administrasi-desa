package com.example.aplikasiadministrasidesaringinsari.feature.auth

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityAuthBinding
import com.example.aplikasiadministrasidesaringinsari.helper.navTo

class AuthActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAuthBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAuthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.run {
            btnLogin.setOnClickListener {
                navTo(LoginActivity::class.java)
            }

            btnSignUp.setOnClickListener {
                navTo(RegisterActivity::class.java)
            }
        }
    }

}