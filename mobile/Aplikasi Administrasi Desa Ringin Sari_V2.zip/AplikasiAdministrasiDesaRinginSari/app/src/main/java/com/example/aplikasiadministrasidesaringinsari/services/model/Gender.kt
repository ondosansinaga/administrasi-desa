package com.example.aplikasiadministrasidesaringinsari.services.model

enum class Gender(val genderInt: Int) {
    LAKI(1),
    PEREMPUAN(0);

    companion object {
        fun getGenderValueInt(spinnerValue: Int): Int {
            return if (spinnerValue == 0) LAKI.genderInt
            else PEREMPUAN.genderInt
        }
    }
}