package com.example.aplikasiadministrasidesaringinsari.common.views

import android.content.Context
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.ArrayAdapter
import androidx.annotation.ArrayRes
import androidx.appcompat.widget.LinearLayoutCompat
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ViewSpinnerBinding
import com.example.aplikasiadministrasidesaringinsari.helper.toPx


class SpinnerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : LinearLayoutCompat(context, attrs) {

    private var _binding: ViewSpinnerBinding? = null

    val spinner get() = _binding?.spView

    init {
        _binding = ViewSpinnerBinding.inflate(LayoutInflater.from(context), this)
        setup()
        bindAttr(context, attrs)
    }

    private fun bindAttr(ctx: Context, attrs: AttributeSet?) {
        val typedArr = ctx.obtainStyledAttributes(attrs, R.styleable.SpinnerView)

        val prefixIcon = typedArr.getDrawable(R.styleable.SpinnerView_sp_src_prefix)
        val valuesId = typedArr.getResourceId(R.styleable.SpinnerView_sp_values, 0)

        setValueFromResources(context, valuesId)
        prefixIcon?.let { setPrefixIcon(it) }

        typedArr.recycle()
    }

    private fun setup() {
        orientation = HORIZONTAL
        setPadding(16.toPx(), 0, 16.toPx(), 0)
        setBackgroundResource(R.drawable.bg_input)
        gravity = Gravity.CENTER
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        _binding?.spView?.isEnabled = enabled
    }

    fun <T> setValueFromArrayList(ctx: Context, list: List<T>) {
        val adapter = ArrayAdapter(
            ctx,
            android.R.layout.simple_spinner_item,
            list
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        _binding?.spView?.adapter = adapter
    }

    fun setValueFromResources(ctx: Context, @ArrayRes textArray: Int) {
        if (textArray == 0) return

        val adapter = ArrayAdapter.createFromResource(
            ctx,
            textArray,
            android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        _binding?.spView?.adapter = adapter
    }

    fun setPrefixIcon(drawable: Drawable) {
        _binding?.ivPrefix?.setImageDrawable(drawable)
    }

    fun activeSpinner(index:Int) {
        spinner?.setSelection(index)
    }

    override fun detachViewFromParent(child: View?) {
        _binding = null
        super.detachViewFromParent(child)
    }

}