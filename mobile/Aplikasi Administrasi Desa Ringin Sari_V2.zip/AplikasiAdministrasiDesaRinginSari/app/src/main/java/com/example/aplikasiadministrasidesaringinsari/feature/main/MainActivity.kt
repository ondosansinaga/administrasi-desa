package com.example.aplikasiadministrasidesaringinsari.feature.main

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.example.aplikasiadministrasidesaringinsari.R
import com.example.aplikasiadministrasidesaringinsari.databinding.ActivityMainBinding
import com.example.aplikasiadministrasidesaringinsari.feature.auth.AuthActivity
import com.example.aplikasiadministrasidesaringinsari.feature.main.menu.beranda.BerandaFragment
import com.example.aplikasiadministrasidesaringinsari.feature.main.menu.pengajuan.PengajuanSuratFragment
import com.example.aplikasiadministrasidesaringinsari.feature.main.menu.profile.ProfileFragment
import com.example.aplikasiadministrasidesaringinsari.feature.main.menu.riwayat.RiwayatPengajuanSuratFragment
import com.example.aplikasiadministrasidesaringinsari.helper.accountManager
import com.example.aplikasiadministrasidesaringinsari.helper.replaceTo
import com.example.aplikasiadministrasidesaringinsari.helper.showConfirmDialog

class MainActivity : AppCompatActivity(), MainActivityListener {

    private lateinit var binding: ActivityMainBinding

    private val selectedMenuIdLive: MutableLiveData<Int> = MutableLiveData()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupNavMenu()

        selectedMenuIdLive.observe(this) { id ->
            activeMenu(id)
            fragmentTransaction(id)
        }
    }

    private fun fragmentTransaction(id: Int) = with(binding) {
        val fragment = when (id) {
            ivBeranda.id -> BerandaFragment()
            ivPengajuan.id -> PengajuanSuratFragment()
            ivRiwayat.id -> RiwayatPengajuanSuratFragment()
            ivProfile.id -> ProfileFragment()
            else -> BerandaFragment()
        }

        supportFragmentManager.beginTransaction()
            .replace(container.id, fragment, null)
            .commit()
    }

    private fun activeMenu(id: Int) = with(binding) {
        ivBeranda.apply {
            if (this.id == id) {
                setImageResource(R.drawable.ic_beranda_fill)
            } else {
                setImageResource(R.drawable.ic_beranda_outline)
            }
        }

        ivPengajuan.apply {
            if (this.id == id) {
                setImageResource(R.drawable.ic_pengajuan_fill)
            } else {
                setImageResource(R.drawable.ic_pengajuan_outline)
            }
        }

        ivRiwayat.apply {
            if (this.id == id) {
                setImageResource(R.drawable.ic_riwayat_fill)
            } else {
                setImageResource(R.drawable.ic_riwayat_outline)
            }
        }

        ivProfile.apply {
            if (this.id == id) {
                setImageResource(R.drawable.ic_profile_fill)
            } else {
                setImageResource(R.drawable.ic_profile_outline)
            }
        }
    }

    private fun setupNavMenu() = with(binding) {
        selectedMenuIdLive.value = ivBeranda.id

        ivBeranda.setOnClickListener {
            selectedMenuIdLive.value = it.id
        }

        ivPengajuan.setOnClickListener {
            selectedMenuIdLive.value = it.id
        }

        ivRiwayat.setOnClickListener {
            selectedMenuIdLive.value = it.id
        }

        ivProfile.setOnClickListener {
            selectedMenuIdLive.value = it.id
        }
    }

    override fun setMenu(menu: MainMenu) = with(binding) {
        when (menu) {
            MainMenu.BERANDA -> {
                tbMain.setTitle(R.string.beranda)
                tbMain.setActionImageResource(null)
            }

            MainMenu.PENGAJUAN -> {
                tbMain.setTitle(R.string.pengajuan_surat)
                tbMain.setActionImageResource(R.drawable.ic_logout_menu)
                tbMain.actionOnClickListener {
                    doLogout()
                }
            }

            MainMenu.RIWAYAT -> {
                tbMain.setTitle(R.string.riwayat_pengajuan)
                tbMain.setActionImageResource(R.drawable.ic_logout_menu)
                tbMain.actionOnClickListener {
                    doLogout()
                }
            }

            MainMenu.PROFIL -> {
                tbMain.setTitle(R.string.profile)
                tbMain.setActionImageResource(R.drawable.ic_logout_menu)
                tbMain.actionOnClickListener {
                    doLogout()
                }
            }

            MainMenu.EDIT_PROFIL -> {
                tbMain.setTitle(R.string.edit_profile)
                tbMain.setActionImageResource(R.drawable.ic_logout_menu)
                tbMain.actionOnClickListener {
                    doLogout()
                }
            }
        }
    }

    private fun doLogout() {
        showConfirmDialog(
            getString(R.string.information),
            getString(R.string.logout_message),
            positiveText = getString(R.string.ya),
            negativeText = getString(R.string.tidak),
        ) {
            accountManager().removeUserId()
            replaceTo(AuthActivity::class.java)
        }
    }

    enum class MainMenu {
        BERANDA,
        PENGAJUAN,
        RIWAYAT,
        PROFIL,
        EDIT_PROFIL,
    }

}

interface MainActivityListener {
    fun setMenu(menu: MainActivity.MainMenu)
}