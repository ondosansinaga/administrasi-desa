package com.example.aplikasiadministrasidesaringinsari.helper

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.aplikasiadministrasidesaringinsari.common.dialog.MessageDialog
import com.example.aplikasiadministrasidesaringinsari.preferences.AccountManager

fun String.getValue(): String? {
    if (this == "-") return null
    return this
}

fun Int.toDp(): Int = (this / Resources.getSystem().displayMetrics.density).toInt()

fun Int.toPx(): Int = (this * Resources.getSystem().displayMetrics.density).toInt()

fun View.closeKeyboard() {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
    imm.hideSoftInputFromWindow(windowToken, 0)
}

fun Activity.navTo(clazz: Class<*>, extra: (Intent.() -> Unit)? = null) {
    Intent(this, clazz).apply {
        extra?.let { this.it() }
    }.run {
        startActivity(this)
    }
}

fun Activity.replaceTo(clazz: Class<*>, extra: (Intent.() -> Unit)? = null) {
    navTo(clazz, extra).run {
        finishAffinity()
    }
}

fun AppCompatActivity.showInfoDialog(message: String, listener: VoidCallback? = null) {
    MessageDialog.build {
        setTitle("Informasi")
        setMessage(message)
        setConfirmAndClickListener("OK", listener)
    }.show(supportFragmentManager, null)
}

fun Fragment.showInfoDialog(
    message: String,
    isCancelable: Boolean = true,
    listener: VoidCallback? = null
) {
    MessageDialog.build {
        setTitle("Informasi")
        setMessage(message)
        setCancelable(isCancelable)
        setConfirmAndClickListener("OK", listener)
    }.show(parentFragmentManager, null)
}

fun AppCompatActivity.showSuccessDialog(message: String, listener: VoidCallback? = null) {
    MessageDialog.build {
        setTitle("Berhasil")
        setMessage(message)
        setConfirmAndClickListener("OK", listener)
    }.apply {
        isCancelable = false
        show(supportFragmentManager, null)
    }
}

fun AppCompatActivity.showConfirmDialog(
    title: String,
    message: String,
    positiveText: String? = null,
    negativeText: String? = null,
    onConfirm: VoidCallback? = null
) {
    MessageDialog.build {
        setTitle(title)
        setMessage(message)
        setConfirmAndClickListener(positiveText, onConfirm)
        setCancelAndClickListener(negativeText)
    }.show(supportFragmentManager, null)
}

fun Fragment.showConfirmDialog(
    title: String,
    message: String,
    positiveText: String? = null,
    negativeText: String? = null,
    onConfirm: VoidCallback? = null
) {
    MessageDialog.build {
        setTitle(title)
        setMessage(message)
        setConfirmAndClickListener(positiveText, onConfirm)
        setCancelAndClickListener(negativeText)
    }.show(parentFragmentManager, null)
}

fun AppCompatActivity.showErrorDialog(message: String) {
    MessageDialog.build {
        setTitle("Gagal")
        setMessage(message)
        setConfirmAndClickListener("OK")
    }.show(supportFragmentManager, null)
}

fun Activity.accountManager(): AccountManager {
    return AccountManager.getInstance(applicationContext)
}