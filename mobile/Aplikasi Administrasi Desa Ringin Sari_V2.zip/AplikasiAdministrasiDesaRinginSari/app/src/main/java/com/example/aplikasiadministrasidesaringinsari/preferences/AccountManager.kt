package com.example.aplikasiadministrasidesaringinsari.preferences

import android.content.Context
import android.content.SharedPreferences

class AccountManager private constructor(context: Context) {

    private var pref: SharedPreferences? = null

    init {
        pref = context.getSharedPreferences(PREF_ACCOUNT, Context.MODE_PRIVATE)
    }

    fun getUserId(): Int? {
        return pref?.getInt(KEY_USER_ID, 0)
    }

    fun setUserId(id: Int?) {
        pref?.edit()
            ?.putInt(KEY_USER_ID, id ?: 0)
            ?.apply()
    }

    fun removeUserId() {
        pref?.edit()
            ?.remove(KEY_USER_ID)
            ?.apply()
    }

    companion object {
        private const val PREF_ACCOUNT = "PREF_ACCOUNT"
        private const val KEY_USER_ID = "KEY_USER_ID"

        @Volatile
        private var INSTANCE: AccountManager? = null

        fun getInstance(context: Context): AccountManager {
            return synchronized(this) {
                INSTANCE ?: AccountManager(context).also {
                    INSTANCE = it
                }
            }
        }
    }


}