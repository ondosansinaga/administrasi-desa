package com.example.aplikasiadministrasidesaringinsari.helper

import java.util.regex.Pattern

const val SPLASH_DELAY = 2000L

val birthInfoPattern: Pattern = Pattern.compile("^.+,\\d{2}-\\d{2}-\\d{4}$")

const val WARGA_ROLE_ID = 2